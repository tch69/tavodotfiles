#!/bin/sh
## Quick script btw
layout=$(setxkbmap -print | awk 'NR==5{print $4}' | grep -o "pc+..")
if [ $layout == "pc+us" ]; then 
     echo "us";
else 
     echo "lol";
fi
