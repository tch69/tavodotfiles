#!/bin/sh
## Alias (?)

# Colorize nearly everything possible
alias \
     ls="ls --color=auto" \
     grep="grep --color=auto" \
     diff="diff --color=auto" \
     egrep="egrep --color=auto" \
     fgrep="fgrep --color=auto"

# cd automatically ls (?)
function cd { builtin cd "$@" && ls -F }

# I don't like cd .. , so.. cd..!
alias cd..="cd .."

